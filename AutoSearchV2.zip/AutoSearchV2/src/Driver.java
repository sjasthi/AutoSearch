import java.awt.Color;
import java.awt.Desktop;
import java.awt.Rectangle;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.poi.hslf.usermodel.HSLFLine;
import org.apache.poi.hslf.usermodel.HSLFPictureData;
import org.apache.poi.hslf.usermodel.HSLFPictureShape;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hslf.usermodel.HSLFTable;
import org.apache.poi.hslf.usermodel.HSLFTableCell;
import org.apache.poi.hslf.usermodel.HSLFTextBox;
import org.apache.poi.hslf.usermodel.HSLFTextParagraph;
import org.apache.poi.hslf.usermodel.HSLFTextRun;
import org.apache.poi.sl.usermodel.TableCell.BorderEdge;
import org.apache.poi.sl.usermodel.TextParagraph.TextAlign;
import org.apache.poi.sl.usermodel.VerticalAlignment;
import org.apache.poi.util.IOUtils;


/**
 * @author Neil Haggerty
 *
 */
public class Driver {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws SQLException 
	 */
	
	
	public static void main(String[] args) throws IOException, SQLException {
		
		//puzzle attributes
		String font = "Arial";
		int puzzleCount = 10;
		int fontSize = 14;
		int colWidth = 25;
		int rowHeight = 25;
		int X = 165;
		int Y = 150;
		boolean showLables = true;
		boolean showBorders = true;
		boolean inEnglish = true;
		
				
		
		PuzzleCollection thePuzzles = new PuzzleCollection(puzzleCount);
		
		
		if(inEnglish) {
			thePuzzles.createPuzzles("english_word_list.txt", inEnglish);
		} else {
			thePuzzles.createPuzzles("telugu_word_list.txt", inEnglish);
		}
		
		createPowerPoint(rowHeight, colWidth, font, fontSize, showLables, showBorders, X, Y, thePuzzles.getPuzzleList());
		
		
	}

	public static void createPowerPoint(int rowHeight, int colWidth, String font, int fontSize, boolean showLables, boolean showBorders, int X, int Y, ArrayList<Puzzle> puzzles) throws IOException, SQLException {
		//create ppt file
		File f = new File("Puzzle.ppt");
		
		//create slide numbers
		int puzzle_slide = 1;
		int solution_slide = puzzle_slide;		
		
		//create slideshow
		HSLFSlideShow ppt = new HSLFSlideShow();
		
		//create labels
		String[] top_label = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",
				"S", "T", "U", "V", "W", "X", "Y", "Z" };
		String[] side_label = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16",
				"17", "18", "19", "20", "21", "22", "23", "24", "25", "26" };
		
		//creating puzzle slides
		for(int count = 0; count<puzzles.size(); count++) {
			Puzzle thePuzzle = puzzles.get(count);
			
			//create slide
			HSLFSlide slide1 = ppt.createSlide();
					
			//create template for slide1
			createTitle(slide1, thePuzzle.getTitle()); //title
			createSlideNum(slide1, puzzle_slide); //number textbox
			createPic(ppt, slide1); //logo
					
			//create text box lines
			createLine(slide1, 220, 30, 50, 0); //top line
			createLine(slide1, 270, 30, 0, 50); //right line
			createLine(slide1, 220, 80, 50, 0); //bottom line
			createLine(slide1, 220, 30, 0, 50); //left line
					
			//create a table for puzzle
			HSLFTable table1 = slide1.createTable(thePuzzle.getRows(), thePuzzle.getCols());
			
			//get the 2d char array
			String grid[][] = thePuzzle.getTheGrid();
			
			//show labels if specified
			if(showLables) {
				HSLFTable top_row = slide1.createTable(1, thePuzzle.getCols());
				HSLFTable side_row = slide1.createTable(thePuzzle.getRows(), 1);
				
				for(int i = 0; i<thePuzzle.getRows(); i++) {
					//side column labels for slide 1
					HSLFTableCell side_cell = side_row.getCell(i, 0);
					side_cell.setText(side_label[i]);
					setBorders(side_cell);
					HSLFTextRun rts1 = side_cell.getTextParagraphs().get(0).getTextRuns().get(0);
					rts1.setFontFamily("Arial");
					rts1.setFontSize(10.);
					side_cell.setVerticalAlignment(VerticalAlignment.MIDDLE);
					side_cell.setHorizontalCentered(true);
				}
				
				
				for(int i = 0; i<Puzzle.getCols(); i++) {
					HSLFTableCell top_cell = top_row.getCell(0, i);
					top_cell.setText(top_label[i]);
					setBorders(top_cell);
					HSLFTextRun rt2s1 = top_cell.getTextParagraphs().get(0).getTextRuns().get(0);
					rt2s1.setFontFamily("Arial");
					rt2s1.setFontSize(10.);
					top_cell.setVerticalAlignment(VerticalAlignment.MIDDLE);
					top_cell.setHorizontalCentered(true);
				}
				
				side_row.setColumnWidth(0, 30);
				top_row.setRowHeight(0, 30);
				
				for (int i = 0; i < thePuzzle.getCols(); i++) {
					top_row.setColumnWidth(i, colWidth);
					
				}
				
				for (int i = 0; i < thePuzzle.getRows(); i++) {
					side_row.setRowHeight(i, rowHeight);
					
				}
				
				top_row.moveTo(X, Y-30);
				side_row.moveTo(X-30, Y);
				
			}
			
			
			//writes appropriate values into table
			for(int i = 0; i<thePuzzle.getCols(); i++) {
				for(int n = 0; n<thePuzzle.getRows(); n++) {
					//writes values from puzzle into tables
					String char_string = String.valueOf(grid[n][i]);
					HSLFTableCell cell1 = table1.getCell(n, i);
					cell1.setText(char_string);
					
					//formats each cell on slide 1
					if(showBorders)
						setBorders(cell1);
				    HSLFTextRun rt1 = cell1.getTextParagraphs().get(0).getTextRuns().get(0);
				    rt1.setFontFamily("Arial");
				    rt1.setFontSize(10.);
				    cell1.setVerticalAlignment(VerticalAlignment.MIDDLE);
				    cell1.setHorizontalCentered(true);
				    
				    
				}
			}
			
			
			//set column width
			for (int i = 0; i < thePuzzle.getCols(); i++) {
				table1.setColumnWidth(i, colWidth);
				
			}
			
			//set row height
			for (int i = 0; i < thePuzzle.getRows(); i++) {
				table1.setRowHeight(i, rowHeight);
				
			}
			
			//move table
			table1.moveTo(X, Y);
			
			
			//increment slide numbers 
			puzzle_slide = puzzle_slide + 1; 
		}
		
		//creating solution slides
		for(int count = 0; count<puzzles.size(); count++) {
			
			//get puzzle from puzzle list
			Puzzle thePuzzle = puzzles.get(count);
			
			//create and format slide
			HSLFSlide slide2 = ppt.createSlide();
			createSlideNum(slide2, solution_slide); 
			createTitle(slide2, thePuzzle.getTitle());
			createPic(ppt, slide2);
			
			//create text box lines 
			createLine(slide2, 220, 30, 50, 0); //top line
			createLine(slide2, 270, 30, 0, 50); //right line
			createLine(slide2, 220, 80, 50, 0); //bottom line
			createLine(slide2, 220, 30, 0, 50); //left line
			
			//create table
			HSLFTable table2 = slide2.createTable(thePuzzle.getRows(), thePuzzle.getCols());
			
			//draw solutions 
			String grid[][] = puzzles.get(count).getTheGrid();
			drawSolutions(table2, puzzles.get(count).getSolutions());
			
			
			//show labels if specified
			if(showLables) {
				HSLFTable top_row = slide2.createTable(1, thePuzzle.getCols());
				HSLFTable side_row = slide2.createTable(thePuzzle.getRows(), 1);
				
				for(int i = 0; i<thePuzzle.getRows(); i++) {
					//side column labels for slide 1
					HSLFTableCell side_cell = side_row.getCell(i, 0);
					side_cell.setText(side_label[i]);
					setBorders(side_cell);
					HSLFTextRun rts1 = side_cell.getTextParagraphs().get(0).getTextRuns().get(0);
					rts1.setFontFamily("Arial");
					rts1.setFontSize(10.);
					side_cell.setVerticalAlignment(VerticalAlignment.MIDDLE);
					side_cell.setHorizontalCentered(true);
				}
				
				
				for(int i = 0; i<thePuzzle.getCols(); i++) {
					HSLFTableCell top_cell = top_row.getCell(0, i);
					top_cell.setText(top_label[i]);
					setBorders(top_cell);
					HSLFTextRun rt2s1 = top_cell.getTextParagraphs().get(0).getTextRuns().get(0);
					rt2s1.setFontFamily("Arial");
					rt2s1.setFontSize(10.);
					top_cell.setVerticalAlignment(VerticalAlignment.MIDDLE);
					top_cell.setHorizontalCentered(true);
				}
				
				side_row.setColumnWidth(0, 30);
				top_row.setRowHeight(0, 30);
				
				for (int i = 0; i < thePuzzle.getCols(); i++) {
					top_row.setColumnWidth(i, colWidth);
					
				}
				
				for (int i = 0; i < thePuzzle.getRows(); i++) {
					side_row.setRowHeight(i, rowHeight);
					
				}
				
				top_row.moveTo(X, Y-30);
				side_row.moveTo(X-30, Y);
				
			}
			
			
			//write appropriate values into table
			for(int i = 0; i<16; i++) {
				for(int n = 0; n<12; n++) {
					//writes values from puzzle into tables
					String char_string = String.valueOf(grid[n][i]);
					HSLFTableCell cell2 = table2.getCell(n, i);
					cell2.setText(char_string);
				    
				    //formats each cell
					if(showBorders)
						setBorders(cell2);
			        HSLFTextRun rt2 = cell2.getTextParagraphs().get(0).getTextRuns().get(0);
			        rt2.setFontFamily("Arial");
			        rt2.setFontSize(10.);
			        cell2.setVerticalAlignment(VerticalAlignment.MIDDLE);
			        cell2.setHorizontalCentered(true);
				}
			}
			
			//set column width
			for (int i = 0; i < thePuzzle.getCols(); i++) {
				table2.setColumnWidth(i, colWidth);
				
			}
			
			//set row height
			for (int i = 0; i < thePuzzle.getRows(); i++) {
				table2.setRowHeight(i, rowHeight);
				
			}
			
			//move table
			table2.moveTo(X, Y);
			
			//increment slide numbers  
			solution_slide = solution_slide + 1;
		}
		
		
		//write data to slideshow
		FileOutputStream out = new FileOutputStream(f);
		ppt.write(out);
		out.close();
		
	
		System.out.println("Puzzle is created to Puzzle.ppt.");
				
		Desktop.getDesktop().browse(f.toURI());
		ppt.close();
	}
	
	public static void setBorders(HSLFTableCell cell) {
		cell.setBorderColor(BorderEdge.bottom, Color.black);
		cell.setBorderColor(BorderEdge.top, Color.black);
		cell.setBorderColor(BorderEdge.right, Color.black);
		cell.setBorderColor(BorderEdge.left, Color.black);
	}
	
	public static void createTitle(HSLFSlide slide, String puzzleName) {
		HSLFTextBox title = slide.createTextBox();
		HSLFTextParagraph p = title.getTextParagraphs().get(0);
		p.setTextAlign(TextAlign.CENTER);
		HSLFTextRun r = p.getTextRuns().get(0);
		r.setBold(true);
		r.setFontColor(Color.black);
		r.setText(puzzleName.toUpperCase());
		r.setFontFamily("Arial");
		r.setFontSize(35.);
		title.setAnchor(new Rectangle(270,30,200,60));
		
	}
	
	public static void createSlideNum(HSLFSlide slide, int slide_num) {
		HSLFTextBox slide_number = slide.createTextBox();
		HSLFTextParagraph p = slide_number.getTextParagraphs().get(0);
		p.setTextAlign(TextAlign.CENTER);
		slide_number.setFillColor(Color.green);
		HSLFTextRun r = p.getTextRuns().get(0);
		r.setText("" + slide_num + "");
		r.setFontFamily("Arial");
		if(slide_num>99) {
			r.setFontSize(20.);
		} else {
			r.setFontSize(30.);
		}
		
		
		slide_number.setAnchor(new Rectangle(220,30,50,50));
	}
	
	public static void createLine(HSLFSlide slide, int x, int y, int x2, int y2) {
		HSLFLine line = new HSLFLine();
		line.setAnchor(new Rectangle(x,y,x2,y2));
		line.setLineColor(Color.black);
		slide.addShape(line);	
	}
	
	public static void createPic(HSLFSlideShow ppt, HSLFSlide slide) throws IOException {
		byte[] picture = IOUtils.toByteArray(new FileInputStream(new File("logo.png")));
		HSLFPictureData pd = ppt.addPicture(picture, HSLFPictureData.PictureType.PNG);
		HSLFPictureShape pic_shape = slide.createPicture(pd);  
		pic_shape.setAnchor(new Rectangle(0, 0, 174, 65));
	}
	

	
	
	public static void drawSolutions(HSLFTable t, ArrayList<String> coords) {
		for(int n = 0; n<coords.size(); n++) {
			String[] current = coords.get(n).split(" ");
			String[] start = current[0].split(",");
			String[] end = current[1].split(",");
			
			int startX = Integer.parseInt(start[1]);
			int startY = Integer.parseInt(start[0]);
			int endX = Integer.parseInt(end[1]);
			int endY = Integer.parseInt(end[0]);
			
			int wordLength;
			
			//this nested if sequence determines what direction the word is going and fills in the appropriate cells
			if((startX - endX)==0) {
				if((startY - endY)>0) {
					wordLength = startY - endY;
					for(int i = 0; i<wordLength+1; i++) {
						HSLFTableCell cell = t.getCell((startX), (startY - i));
						cell.setFillColor(Color.green);
						
					}
					
				} else {
					wordLength = endY - startY;
					for(int i = 0; i<wordLength+1; i++) {
						HSLFTableCell cell = t.getCell((startX), (startY + i));
						cell.setFillColor(Color.green);
						
					}
				}
			} else if((startX - endX)>0) {
				wordLength = startX - endX;
				if((endY - startY)==0) {
					for(int i = 0; i<wordLength+1; i++) {
						HSLFTableCell cell = t.getCell((startX - i), (startY));
						cell.setFillColor(Color.green);
						
					}
				} else if((endY - startY)>0) {
					for(int i = 0; i<wordLength+1; i++) {
						HSLFTableCell cell = t.getCell((startX - i), (startY + i));
						cell.setFillColor(Color.green);
						
					}
				} else {
					for(int i = 0; i<wordLength+1; i++) {
						HSLFTableCell cell = t.getCell((startX - i), (startY - i));
						cell.setFillColor(Color.green);
						
					}
				}
			} else {
				wordLength = endX - startX;
				if((endY - startY)==0) {
					for(int i = 0; i<wordLength+1; i++) {
						HSLFTableCell cell = t.getCell((startX + i), (startY));
						cell.setFillColor(Color.green);
						
					}
				} else if((endY - startY)>0) {
					for(int i = 0; i<wordLength+1; i++) {
						HSLFTableCell cell = t.getCell((startX + i), (startY + i));
						cell.setFillColor(Color.green);
						
					}
				} else {
					for(int i = 0; i<wordLength+1; i++) {
						HSLFTableCell cell = t.getCell((startX + i), (startY - i));
						cell.setFillColor(Color.green);
						
					}
				}
			}
			
			
			
		}
	}
	
	
}
