import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class PuzzleCollection {
	private int count;
	
	private ArrayList<Puzzle> puzzleList = new ArrayList<Puzzle>();
	
	
	public PuzzleCollection(int count) {
		this.count = count;
		if(this.count>50) {
			this.count = 50;
			System.out.println("Max puzzle count is 50");
		}
		
	}

	
	
	public void createPuzzles(String file_name, boolean inEnglish) throws FileNotFoundException {
		//set up file to import words from
		File file = new File(file_name);
		Scanner s1 = new Scanner(file, "UTF-8");
		
		//create api for web service calls
		API api = new API();
		
		//set up language
		String lang = "";
		if(inEnglish) {
			lang = "English";
		} else {
			lang = "telugu";
		}
		
		//get data for puzzles
		int rows = getRowsFromDatabase();
		int cols = getColsFromDatabase();
		
		//parse words from text file
		for(int i = 0; i<count; i++) {
			int puzzleID = 0;
			int wordCount = 0;
			String title = "";
			ArrayList<String> wordList = new ArrayList<String>();
			
			while(s1.hasNextLine()&&wordCount<10) {
				String line = s1.nextLine();
				String[] tokens = new String[4];
				tokens = line.split(",");
				puzzleID = Integer.parseInt(tokens[0]);
				title = tokens[2];
				wordList.add(tokens[3].toUpperCase());
				wordCount++;
			}
			
			//create puzzle
			Puzzle puzzle = new Puzzle(puzzleID, title, wordList, rows, cols, api.getFillerCharacters(200, lang));
			
			//add puzzle to list for later use
			puzzleList.add(puzzle);
		}
		
		
	}
	
	public static int getRowsFromDatabase() {
		Connection db_connection = null;
		int rows = 0;
		try {

			String url = "jdbc:mysql://localhost/autosearch";
			String user = "root";
			String password = "";
			db_connection = DriverManager.getConnection(url, user, password);
			System.out.println("Success: Connection established");

			Statement statement_object = db_connection.createStatement();

			String sql_query_str = "SELECT * FROM dimensions";
			ResultSet result_set = statement_object.executeQuery(sql_query_str);

			while (result_set.next()) {
				rows = result_set.getInt("rows");
				System.out.println("rows = "+rows);
				

			} // end while

		} // end try

		catch (Exception ex) {
			ex.printStackTrace();
		} // end catch
		
		return rows;
	}

	public static int getColsFromDatabase() {
		Connection db_connection = null;
		int columns = 0;
		try {		
			

			String url = "jdbc:mysql://localhost/autosearch";
			String user = "root";
			String password = "";
			db_connection = DriverManager.getConnection(url, user, password);

			Statement statement_object = db_connection.createStatement();

			String sql_query_str = "SELECT * FROM dimensions";
			ResultSet result_set = statement_object.executeQuery(sql_query_str);
			
			while (result_set.next()) {
				columns = result_set.getInt("columns");
				System.out.println("columns = "+columns);
				

			} // end while

		} // end try

		catch (Exception ex) {
			ex.printStackTrace();
		} // end catch
		
		return columns;
	}
	
	public ArrayList<Puzzle> getPuzzleList(){
		return puzzleList;
	}
	
}
